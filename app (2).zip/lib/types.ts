export type AnswerValue = string | number | boolean | string[] | undefined;
export type AnswerMap = Record<string, AnswerValue>;
